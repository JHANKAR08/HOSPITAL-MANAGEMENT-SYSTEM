# Hospital Management System

> Team MicroProject for **Problem Solving with Python Course**, Semester 3, B-tech at APJ Abdul Kalam Technological University